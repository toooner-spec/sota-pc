"""State of the Art - Web/Desktop entry point (pygbag compatible)."""

import asyncio
import sys
import os
import pygame


async def main():
    pygame.init()
    # Yield to browser to let SDL2/canvas initialize
    await asyncio.sleep(0)

    RENDER_WIDTH = 320
    RENDER_HEIGHT = 200
    DISPLAY_SCALE = 2
    width = RENDER_WIDTH * DISPLAY_SCALE
    height = RENDER_HEIGHT * DISPLAY_SCALE

    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("State of the Art - Spaceballs 1992")

    # Show loading message
    screen.fill((0, 0, 40))
    font = pygame.font.Font(None, 36)
    surf = font.render("Loading State of the Art...", True, (255, 255, 255))
    screen.blit(surf, (width // 2 - surf.get_width() // 2, height // 2))
    pygame.display.flip()
    await asyncio.sleep(0)

    try:
        cwd = os.getcwd()
        if cwd not in sys.path:
            sys.path.insert(0, cwd)
        try:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            if script_dir not in sys.path:
                sys.path.insert(0, script_dir)
        except Exception:
            pass

        from sota.wad import WadFile
        from sota.choreography import ChoreographyEngine
        from sota.graphics import composite_bitplanes

        try:
            import numpy as np
            has_np = True
        except ImportError:
            has_np = False

        wad = None
        wad_error = None
        for candidate in ['assets/sota.wad', 'sota.wad',
                          os.path.join(cwd, 'assets', 'sota.wad'),
                          os.path.join(cwd, 'sota.wad')]:
            try:
                wad = WadFile.from_file(candidate)
                print(f"Loaded WAD: {candidate} ({wad.file_count} files)")
                break
            except Exception as e:
                wad_error = f"{candidate}: {e}"
                continue

        if wad is None:
            screen.fill((40, 0, 0))
            font = pygame.font.Font(None, 24)
            for i, line in enumerate(f"WAD not found\n{wad_error}\ncwd={cwd}".split('\n')):
                s = font.render(line[:80], True, (255, 255, 100))
                screen.blit(s, (10, 10 + i * 28))
            pygame.display.flip()
            for _ in range(300):
                for ev in pygame.event.get():
                    pass
                await asyncio.sleep(0.1)
            return

        render_surface = pygame.Surface((RENDER_WIDTH, RENDER_HEIGHT), 0, 32)

        sound = None
        try:
            from sota.sound import SoundPlayer
            player = SoundPlayer()
            if player.initialized:
                sound = player
        except Exception:
            pass

        engine = ChoreographyEngine(wad, RENDER_WIDTH, RENDER_HEIGHT, sound)
        engine.prepare_to_run(0)

        clock = pygame.time.Clock()
        start_time = pygame.time.get_ticks()
        running = True

        print(f"Demo started. numpy={has_np}")

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False

            current_ms = pygame.time.get_ticks() - start_time
            engine.do_frame(current_ms)

            if engine.end_of_demo_flag:
                engine.prepare_to_run(0)
                start_time = pygame.time.get_ticks()
                await asyncio.sleep(0)
                continue

            framebuffer = composite_bitplanes(
                engine.bitplanes, RENDER_WIDTH, RENDER_HEIGHT,
                engine.palette, engine.copper_func
            )

            if has_np:
                import numpy as np
                rgb_array = np.zeros((RENDER_HEIGHT, RENDER_WIDTH, 3), dtype=np.uint8)
                rgb_array[:, :, 0] = (framebuffer >> 16) & 0xFF
                rgb_array[:, :, 1] = (framebuffer >> 8) & 0xFF
                rgb_array[:, :, 2] = framebuffer & 0xFF
                pygame.surfarray.blit_array(render_surface, rgb_array.transpose(1, 0, 2))
            else:
                buf = bytearray(RENDER_WIDTH * RENDER_HEIGHT * 3)
                idx = 0
                for y in range(RENDER_HEIGHT):
                    row = framebuffer[y]
                    for x in range(RENDER_WIDTH):
                        argb = row[x]
                        buf[idx] = (argb >> 16) & 0xFF
                        buf[idx + 1] = (argb >> 8) & 0xFF
                        buf[idx + 2] = argb & 0xFF
                        idx += 3
                img = pygame.image.frombuffer(bytes(buf), (RENDER_WIDTH, RENDER_HEIGHT), 'RGB')
                render_surface.blit(img, (0, 0))

            scaled = pygame.transform.scale(render_surface, (width, height))
            screen.blit(scaled, (0, 0))
            pygame.display.flip()

            if sound is not None:
                sound.update()

            await asyncio.sleep(0)
            clock.tick(50)

    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        print(f"ERROR: {tb}")

    pygame.quit()


asyncio.run(main())
