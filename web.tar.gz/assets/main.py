"""State of the Art - Web/Desktop entry point (pygbag compatible).

Run locally:    python main.py
Build for web:  python build_web.py --build
Serve locally:  python build_web.py
"""

import asyncio

async def main():
    import sys
    import os

    # Ensure sota package is importable
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

    import pygame

    try:
        import numpy as np
        HAS_NUMPY = True
    except ImportError:
        HAS_NUMPY = False

    from sota.wad import WadFile
    from sota.choreography import ChoreographyEngine
    from sota.graphics import composite_bitplanes

    # Display settings
    RENDER_WIDTH = 320
    RENDER_HEIGHT = 200
    DISPLAY_SCALE = 2

    # Find WAD
    wad_path = None
    for candidate in ['assets/sota.wad', 'sota.wad']:
        if os.path.exists(candidate):
            wad_path = candidate
            break

    if wad_path is None:
        print("Error: sota.wad not found")
        return

    print(f"Loading WAD: {wad_path}")
    wad = WadFile.from_file(wad_path)
    print(f"WAD loaded: {wad.file_count} files")

    # Initialize pygame
    pygame.init()

    width = RENDER_WIDTH * DISPLAY_SCALE
    height = RENDER_HEIGHT * DISPLAY_SCALE

    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("State of the Art - Spaceballs 1992")

    render_surface = pygame.Surface((RENDER_WIDTH, RENDER_HEIGHT), 0, 32)

    # Sound (may fail in browser)
    sound = None
    try:
        from sota.sound import SoundPlayer
        player = SoundPlayer()
        if player.initialized:
            sound = player
    except Exception:
        pass

    # Choreography engine
    engine = ChoreographyEngine(wad, RENDER_WIDTH, RENDER_HEIGHT, sound)
    engine.prepare_to_run(0)

    clock = pygame.time.Clock()
    start_time = pygame.time.get_ticks()
    running = True

    print("Demo started.")

    while running:
        # Events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

        # Current demo time
        current_ms = pygame.time.get_ticks() - start_time

        # Run choreography
        engine.do_frame(current_ms)

        if engine.end_of_demo_flag:
            engine.prepare_to_run(0)
            start_time = pygame.time.get_ticks()
            await asyncio.sleep(0)
            continue

        # Composite and render
        framebuffer = composite_bitplanes(
            engine.bitplanes, RENDER_WIDTH, RENDER_HEIGHT,
            engine.palette, engine.copper_func
        )

        # Convert framebuffer to pygame surface
        if HAS_NUMPY:
            rgb_array = np.zeros((RENDER_HEIGHT, RENDER_WIDTH, 3), dtype=np.uint8)
            rgb_array[:, :, 0] = (framebuffer >> 16) & 0xFF
            rgb_array[:, :, 1] = (framebuffer >> 8) & 0xFF
            rgb_array[:, :, 2] = framebuffer & 0xFF
            pygame.surfarray.blit_array(render_surface, rgb_array.transpose(1, 0, 2))
        else:
            # Pure Python path: write pixels directly
            pixels = pygame.PixelArray(render_surface)
            for y in range(RENDER_HEIGHT):
                row = framebuffer[y]
                for x in range(RENDER_WIDTH):
                    argb = row[x]
                    # Convert ARGB to RGB for pygame
                    pixels[x, y] = (argb & 0x00FFFFFF)
            pixels.close()

        # Scale and display
        scaled = pygame.transform.scale(render_surface, (width, height))
        screen.blit(scaled, (0, 0))
        pygame.display.flip()

        if sound is not None:
            sound.update()

        # Yield to browser / frame timing
        await asyncio.sleep(0)
        clock.tick(50)

    if sound is not None:
        sound.shutdown()
    pygame.quit()


asyncio.run(main())
