"""Planar bitplane rendering engine for State of the Art.

Faithfully emulates the Amiga's planar display system:
- Up to 6 bitplanes, each a 1-bit-per-pixel buffer
- Scanline polygon fill (matching the Amiga blitter XOR fill)
- Bresenham line drawing with thickness
- Circle drawing (midpoint algorithm)
- Bitplane compositing with palette lookup
- Copper effects (per-scanline palette modification)
"""

import math

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False


class Bitplane:
    """A single bitplane: 1-bit-per-pixel packed buffer (MSB first, like Amiga)."""

    def __init__(self, idx: int, width: int, height: int):
        self.idx = idx
        self.width = width
        self.height = height
        self.stride = width // 8  # bytes per row
        self.data = bytearray(self.stride * height)
        self.data_offset = 0  # for viewport shifting effects

    def clear(self):
        for i in range(len(self.data)):
            self.data[i] = 0

    def putpixel(self, x: int, y: int):
        if 0 <= x < self.width and 0 <= y < self.height:
            byte_idx = (y * self.stride) + (x >> 3) + self.data_offset
            if 0 <= byte_idx < len(self.data):
                self.data[byte_idx] |= (1 << (7 - (x & 7)))

    def getpixel(self, x: int, y: int) -> int:
        if 0 <= x < self.width and 0 <= y < self.height:
            byte_idx = (y * self.stride) + (x >> 3) + self.data_offset
            if 0 <= byte_idx < len(self.data):
                return 1 if (self.data[byte_idx] & (1 << (7 - (x & 7)))) else 0
        return 0

    def copy_from(self, other: 'Bitplane'):
        """Copy entire contents from another bitplane of same dimensions."""
        if self.width == other.width and self.height == other.height:
            self.data[:] = other.data[:]

    def get_row_bytes(self, y: int) -> memoryview:
        """Get a memoryview to the byte data for row y."""
        start = y * self.stride + self.data_offset
        return memoryview(self.data)[start:start + self.stride]


def line_horizontal(plane: Bitplane, y: int, start_x: int, end_x: int, xor: bool, pattern: int = 0xFFFF):
    """Draw a horizontal line on the bitplane. Pattern is a 16-bit repeating pattern."""
    y = max(0, min(y, plane.height - 1))
    start_x = max(0, min(start_x, plane.width - 1))
    end_x = max(0, min(end_x, plane.width - 1))

    if start_x > end_x:
        return

    pattern32 = ((pattern & 0xFFFF) << 16) | (pattern & 0xFFFF)
    row_start = y * plane.stride + plane.data_offset

    for x in range(start_x, end_x + 1):
        byte_idx = row_start + (x >> 3)
        bit_mask = 1 << (7 - (x & 7))

        # Check pattern bit
        pat_bit = (pattern32 >> (31 - (x & 31))) & 1
        if not pat_bit:
            continue

        if byte_idx < len(plane.data):
            if xor:
                plane.data[byte_idx] ^= bit_mask
            else:
                plane.data[byte_idx] |= bit_mask


def line_vertical(plane: Bitplane, x: int, start_y: int, end_y: int, xor: bool, pattern: int = 0xFFFF):
    """Draw a vertical line on the bitplane."""
    x = max(0, min(x, plane.width - 1))
    start_y = max(0, min(start_y, plane.height - 1))
    end_y = max(0, min(end_y, plane.height - 1))

    if start_y > end_y:
        return

    bit_mask = 1 << (7 - (x & 7))
    x_byte = x >> 3
    pat = pattern

    for y_pos in range(start_y, end_y + 1):
        byte_idx = y_pos * plane.stride + x_byte + plane.data_offset
        if byte_idx < len(plane.data) and (pat & 0x8000):
            if xor:
                plane.data[byte_idx] ^= bit_mask
            else:
                plane.data[byte_idx] |= bit_mask
        # Rotate pattern left by 1
        pat = ((pat << 1) & 0xFFFF) | ((pat >> 15) & 1)


def line_thick(plane: Bitplane, x0: int, y0: int, x1: int, y1: int, thickness: int):
    """Bresenham's line algorithm with thickness (for outline drawing)."""
    dx = abs(x1 - x0)
    sx = 1 if x0 < x1 else -1
    dy = abs(y1 - y0)
    sy = 1 if y0 < y1 else -1
    err = (dx if dx > dy else -dy) // 2
    half = thickness // 2
    max_steps = max(dx, dy) + 1

    for _ in range(max_steps):
        for yt in range(-half, half):
            for xt in range(-half, half + 1):
                plane.putpixel(x0 + xt, y0 + yt)

        if x0 == x1 and y0 == y1:
            break

        e2 = err
        if e2 > -dx:
            err -= dy
            x0 += sx
        if e2 < dy:
            err += dx
            y0 += sy


def draw_scaled_polygon_outline(num_vertices: int, data: bytes, scalex: float, scaley: float,
                                xofs: int, yofs: int, plane: Bitplane, outline_width: int):
    """Draw a polygon outline (no fill) with scaling."""
    if num_vertices < 2:
        return

    # First vertex
    first_y = int(data[0] * scaley + yofs)
    first_x = int(data[1] * scalex + xofs)
    prev_x, prev_y = first_x, first_y

    for i in range(1, num_vertices):
        cy = int(data[i * 2] * scaley + yofs)
        cx = int(data[i * 2 + 1] * scalex + xofs)
        line_thick(plane, prev_x, prev_y, cx, cy, outline_width)
        prev_x, prev_y = cx, cy

    # Close shape
    line_thick(plane, prev_x, prev_y, first_x, first_y, outline_width)


def draw_filled_scaled_polygon(num_vertices: int, data: bytes, scalex: float, scaley: float,
                               xofs: int, yofs: int, plane: Bitplane,
                               xor_mode: bool, distort: bool,
                               flip_horizontal: bool, flip_vertical: bool):
    """Draw a filled polygon using scanline fill algorithm.

    This matches the nfd/sota reference: edge table + active edge list scanline fill.
    """
    if num_vertices < 2:
        return

    w = plane.width
    h = plane.height

    # Build edge table
    edges = []  # list of (ymin, ymax, x_at_ymin, grad_recip)
    global_ymin = h
    global_ymax = 0

    for i in range(num_vertices):
        y0 = data[i * 2]
        x0 = data[i * 2 + 1]

        if i == num_vertices - 1:
            y1 = data[0]
            x1 = data[1]
        else:
            y1 = data[(i + 1) * 2]
            x1 = data[(i + 1) * 2 + 1]

        if distort:
            if i & 1:
                x0 += 8
            else:
                x1 += 8

        y0 = int(y0 * scaley + yofs)
        y1 = int(y1 * scaley + yofs)
        x0 = int(x0 * scalex + xofs)
        x1 = int(x1 * scalex + xofs)

        if y0 == y1:
            continue  # skip horizontal edges

        if flip_horizontal:
            x0 = w - x0
            x1 = w - x1

        if flip_vertical:
            y0 = h - y0
            y1 = h - y1

        # Ensure y0 <= y1
        if y0 > y1:
            y0, y1 = y1, y0
            x0, x1 = x1, x0

        y0 = max(0, min(y0, h - 1))
        y1 = max(0, min(y1, h - 1))
        x0 = max(0, min(x0, w - 1))
        x1 = max(0, min(x1, w - 1))

        if y0 < global_ymin:
            global_ymin = y0
        if y1 > global_ymax:
            global_ymax = y1

        grad_recip = (x1 - x0) / (y1 - y0) if y1 != y0 else 0.0

        edges.append({
            'ymin': y0, 'ymax': y1,
            'xmin': x0, 'xcurr': float(x0),
            'grad_recip': grad_recip,
        })

    if not edges:
        return

    # Build per-scanline edge table buckets
    edge_table = {}
    for edge in edges:
        ymin = edge['ymin']
        if ymin not in edge_table:
            edge_table[ymin] = []
        edge_table[ymin].append(edge)

    # Scanline fill
    active_list = []

    for y in range(global_ymin, global_ymax + 1):
        # Add edges starting at this scanline
        if y in edge_table:
            active_list.extend(edge_table[y])

        # Sort active edges by xcurr
        active_list.sort(key=lambda e: e['xcurr'])

        # Draw fill lines between pairs
        is_drawing = False
        prev_x = 0
        for edge in active_list:
            if is_drawing:
                next_x = int(math.floor(edge['xcurr']))
            else:
                next_x = int(math.ceil(edge['xcurr']))

            is_vertex = (abs(edge['xmin'] - edge['xcurr']) < 0.5
                         and (edge['ymax'] == y or edge['ymin'] == y))

            if is_drawing:
                line_horizontal(plane, y, prev_x, next_x, xor_mode, 0xFFFF)

            if (not is_vertex) or (edge['ymax'] == y):
                is_drawing = not is_drawing

            prev_x = next_x

        # Remove edges where ymax == y
        active_list = [e for e in active_list if e['ymax'] != y]

        # Update xcurr
        for edge in active_list:
            edge['xcurr'] += edge['grad_recip']


def draw_thick_circle(plane: Bitplane, xc: int, yc: int, radius: int, thickness: int):
    """Draw a thick circle (annulus) using midpoint algorithm."""
    if radius <= 0:
        return

    xouter = radius
    xinner = radius - thickness
    y = 0
    err_outer = 1 - xouter
    err_inner = 1 - xinner

    while xouter >= y:
        line_horizontal(plane, yc + y, xc + xinner, xc + xouter, False)
        line_vertical(plane, xc + y, yc + xinner, yc + xouter, False)
        line_horizontal(plane, yc + y, xc - xouter, xc - xinner, False)
        line_vertical(plane, xc - y, yc + xinner, yc + xouter, False)
        line_horizontal(plane, yc - y, xc - xouter, xc - xinner, False)
        line_vertical(plane, xc - y, yc - xouter, yc - xinner, False)
        line_horizontal(plane, yc - y, xc + xinner, xc + xouter, False)
        line_vertical(plane, xc + y, yc - xouter, yc - xinner, False)

        y += 1
        if err_outer < 0:
            err_outer += 2 * y + 1
        else:
            xouter -= 1
            err_outer += 2 * (y - xouter + 1)

        if y > radius:
            xinner = y
        else:
            if err_inner < 0:
                err_inner += 2 * y + 1
            else:
                xinner -= 1
                err_inner += 2 * (y - xinner + 1)


def draw_circle(plane: Bitplane, x0: int, y0: int, radius: int):
    """Draw a 1-pixel circle using midpoint algorithm."""
    x = radius
    y = 0
    err = 0

    while x >= y:
        plane.putpixel(x0 + x, y0 + y)
        plane.putpixel(x0 + y, y0 + x)
        plane.putpixel(x0 - y, y0 + x)
        plane.putpixel(x0 - x, y0 + y)
        plane.putpixel(x0 - x, y0 - y)
        plane.putpixel(x0 - y, y0 - x)
        plane.putpixel(x0 + y, y0 - x)
        plane.putpixel(x0 + x, y0 - y)

        y += 1
        err += 1 + 2 * y
        if 2 * (err - x) + 1 > 0:
            x -= 1
            err += 1 - 2 * x


def filled_rect(plane: Bitplane, sx: int, sy: int, ex: int, ey: int):
    """Draw a filled rectangle."""
    sy = max(0, min(sy, plane.height - 1))
    ey = max(0, min(ey, plane.height - 1))
    sx = max(0, min(sx, plane.width - 1))
    ex = max(0, min(ex, plane.width - 1))

    if sx > ex or sy > ey:
        return

    for y in range(sy, ey + 1):
        line_horizontal(plane, y, sx, ex, False, 0xFFFF)


def copy_plane(src: Bitplane, dst: Bitplane):
    """Fast copy entire bitplane contents."""
    if src.width == dst.width and src.height == dst.height:
        dst.data[:] = src.data[:]


def bitplane_blit(src: Bitplane, dst: Bitplane, sx: int, sy: int, w: int, h: int, dx: int, dy: int):
    """Blit a region from one bitplane to another (byte-aligned simplified version)."""
    for row in range(h):
        src_y = sy + row
        dst_y = dy + row
        if src_y < 0 or src_y >= src.height or dst_y < 0 or dst_y >= dst.height:
            continue
        # Byte-aligned copy for speed
        src_start_byte = src_y * src.stride + sx // 8
        dst_start_byte = dst_y * dst.stride + dx // 8
        num_bytes = w // 8
        for b in range(num_bytes):
            si = src_start_byte + b + src.data_offset
            di = dst_start_byte + b + dst.data_offset
            if 0 <= si < len(src.data) and 0 <= di < len(dst.data):
                dst.data[di] = src.data[si]


def lerp_palette(num_elements: int, from_pal: list, to_pal: list,
                 current_step: int, total_steps: int) -> list:
    """Linearly interpolate between two palettes. Returns list of ARGB uint32 values."""
    if current_step < 0 or current_step > total_steps or total_steps == 0:
        return from_pal[:num_elements]

    result = []
    for i in range(min(num_elements, len(from_pal), len(to_pal))):
        f = from_pal[i]
        t = to_pal[i]
        lerped = 0xFF000000
        for shift in (16, 8, 0):  # R, G, B bytes
            fb = (f >> shift) & 0xFF
            tb = (t >> shift) & 0xFF
            lb = fb + ((tb - fb) * current_step) // total_steps
            lb = max(0, min(255, lb))
            lerped |= lb << shift
        result.append(lerped)

    return result


def _make_ehb_palette(palette: list) -> list:
    """Build a 64-entry palette list with EHB (Extra Half-Brite) entries."""
    pal = list(palette[:32])
    while len(pal) < 32:
        pal.append(0xFF000000)
    for i in range(32):
        c = pal[i]
        ehb = (0xFF000000
               | (((c & 0x00FF0000) >> 17) << 16)
               | (((c & 0x0000FF00) >> 9) << 8)
               | (((c & 0x000000FF) >> 1)))
        pal.append(ehb)
    return pal


# Precomputed bit unpacking table: for each byte (0-255), gives 8 bit values (MSB first)
_UNPACK_TABLE_LIST = [[0] * 8 for _ in range(256)]
for _b in range(256):
    for _bit in range(8):
        _UNPACK_TABLE_LIST[_b][7 - _bit] = (_b >> _bit) & 1

if HAS_NUMPY:
    _UNPACK_TABLE = np.array(_UNPACK_TABLE_LIST, dtype=np.uint8)


def composite_bitplanes(bitplanes: list, width: int, height: int,
                        palette: list, copper_func=None):
    """Composite up to 6 bitplanes into an ARGB framebuffer.

    Returns numpy array if numpy is available, else list-of-lists.
    Uses numpy for bulk operations on desktop. Falls back to pure Python for web.
    """
    pal_list = _make_ehb_palette(palette)

    if HAS_NUMPY and copper_func is None:
        return _composite_numpy(bitplanes, width, height, pal_list)
    else:
        return _composite_pure(bitplanes, width, height, pal_list, copper_func)


def _composite_numpy(bitplanes, width, height, pal_list):
    """Fast numpy compositing path (desktop)."""
    pal_array = np.array(pal_list, dtype=np.uint32)
    stride = width // 8

    color_indices = np.zeros((height, width), dtype=np.uint8)

    for p_idx in range(6):
        bp = bitplanes[p_idx]
        if bp is None or bp.data is None or len(bp.data) == 0:
            continue

        bit_val = 1 << p_idx

        plane_array = np.zeros((height, stride), dtype=np.uint8)
        for y in range(height):
            src_start = y * bp.stride + bp.data_offset
            if 0 <= src_start < len(bp.data):
                row_len = min(stride, max(0, len(bp.data) - src_start))
                if row_len > 0:
                    plane_array[y, :row_len] = np.frombuffer(
                        bp.data, dtype=np.uint8, count=row_len, offset=src_start
                    )

        unpacked = _UNPACK_TABLE[plane_array].reshape(height, width)
        color_indices |= (unpacked * bit_val).astype(np.uint8)

    return pal_array[color_indices]


def _composite_pure(bitplanes, width, height, pal_list, copper_func=None):
    """Pure Python compositing (web/fallback). Returns list-of-lists of uint32."""
    stride = width // 8
    working_pal = list(pal_list)
    copper_check_step = max(1, width // 40)

    # Pre-gather bitplane data refs for speed
    bp_data = []
    for p_idx in range(6):
        bp = bitplanes[p_idx]
        if bp is not None and bp.data is not None and len(bp.data) > 0:
            bp_data.append((bp.data, bp.stride, bp.data_offset, 1 << p_idx))
        else:
            bp_data.append(None)

    framebuffer = [[0] * width for _ in range(height)]

    for y in range(height):
        next_copper_check = 0

        # Gather row bytes for each plane
        row_bytes = []
        for info in bp_data:
            if info is not None:
                data, bp_stride, data_offset, _ = info
                src = y * bp_stride + data_offset
                row = bytearray(stride)
                avail = min(stride, max(0, len(data) - src))
                if src >= 0 and avail > 0:
                    row[:avail] = data[src:src + avail]
                row_bytes.append(row)
            else:
                row_bytes.append(None)

        row_out = framebuffer[y]
        for byte_x in range(stride):
            x = byte_x * 8

            if copper_func is not None and x >= next_copper_check:
                copper_func(x * 40 // width, y * 256 // height, working_pal)
                next_copper_check += copper_check_step

            # Build 8 pixel color indices from all planes at once
            for bit in range(8):
                mask = 1 << (7 - bit)
                idx = 0
                for pi in range(6):
                    rb = row_bytes[pi]
                    if rb is not None and rb[byte_x] & mask:
                        idx |= (1 << pi)
                px = x + bit
                if px < width:
                    row_out[px] = working_pal[idx & 63]

        if copper_func is not None:
            working_pal[:] = pal_list

    # Wrap as numpy if available, else return as-is
    if HAS_NUMPY:
        return np.array(framebuffer, dtype=np.uint32)
    return framebuffer
