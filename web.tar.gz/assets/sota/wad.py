"""WAD container parser for State of the Art demo data.

The WAD format (from nfd/sota):
- Header (12 bytes): magic 'mess' (4B), file_count (4B), choreography_file_idx (4B)
- Index (8 bytes per entry): offset (4B), size (4B)
- File data: Raw blobs at indexed offsets
"""

import struct

ENDIAN = '<'
WAD_MAGIC = b'mess'


class WadFile:
    """Represents a parsed WAD container with random access to contained files."""

    def __init__(self, data: bytes):
        self._data = data
        self._parse_header()

    def _parse_header(self):
        magic = self._data[:4]
        if magic != WAD_MAGIC:
            raise ValueError(f"Invalid WAD magic: {magic!r}, expected {WAD_MAGIC!r}")

        self.file_count, self.choreography_idx = struct.unpack_from(
            ENDIAN + 'II', self._data, 4
        )

        self._index = []
        offset = 12  # after header
        for i in range(self.file_count):
            file_offset, file_size = struct.unpack_from(ENDIAN + 'II', self._data, offset)
            self._index.append((file_offset, file_size))
            offset += 8

    def get_file(self, idx: int) -> bytes:
        """Return the raw bytes of file at index idx."""
        if idx < 0 or idx >= self.file_count:
            raise IndexError(f"File index {idx} out of range (0..{self.file_count - 1})")
        file_offset, file_size = self._index[idx]
        return self._data[file_offset:file_offset + file_size]

    def get_file_offset(self, idx: int) -> int:
        if idx < 0 or idx >= self.file_count:
            return 0
        return self._index[idx][0]

    def get_file_size(self, idx: int) -> int:
        if idx < 0 or idx >= self.file_count:
            return 0
        return self._index[idx][1]

    def get_choreography(self) -> bytes:
        """Return the choreography data."""
        return self.get_file(self.choreography_idx)

    def get_choreography_offset(self) -> int:
        """Return the offset of the choreography data within the WAD."""
        return self.get_file_offset(self.choreography_idx)

    @classmethod
    def from_file(cls, path: str) -> 'WadFile':
        with open(path, 'rb') as f:
            return cls(f.read())


class WadBuilder:
    """Build a WAD file from individual data blobs (matching nfd/sota's wad.py)."""

    def __init__(self, endian=ENDIAN):
        self.files = []  # list of (size, data) tuples
        self.filename_to_idx = {}
        self.choreography_idx = -1
        self.endian = endian

    def add(self, filename: str, is_choreography=False) -> int:
        if filename in self.filename_to_idx:
            return self.filename_to_idx[filename]

        with open(filename, 'rb') as f:
            filedata = f.read()

        idx = self.add_bin(filedata, is_choreography=is_choreography)
        self.filename_to_idx[filename] = idx
        return idx

    def add_bin(self, filedata: bytes, is_choreography=False, filename=None) -> int:
        if filename is not None and filename in self.filename_to_idx:
            return self.filename_to_idx[filename]

        idx = len(self.files)
        filelength = len(filedata)
        if len(filedata) % 4 != 0:
            filedata += b'\0' * (4 - (len(filedata) % 4))

        self.files.append((filelength, filedata))

        if is_choreography:
            self.choreography_idx = idx

        if filename is not None:
            self.filename_to_idx[filename] = idx

        return idx

    def write(self, filename: str) -> int:
        first_file_position = 4 + 4 + 4 + (len(self.files) * 4 * 2)
        next_file_position = first_file_position

        with open(filename, 'wb') as f:
            f.write(WAD_MAGIC)
            f.write(struct.pack(self.endian + 'II', len(self.files), self.choreography_idx))

            for filelength, filedata in self.files:
                f.write(struct.pack(self.endian + 'II', next_file_position, filelength))
                next_file_position += len(filedata)

            for filelength, filedata in self.files:
                f.write(filedata)

        return first_file_position
