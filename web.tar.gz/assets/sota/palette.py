"""Palette and copper effect handling for State of the Art."""

import math

# Copper pastels grid dimensions
COPPER_PASTELS_WIDTH = 16
COPPER_PASTELS_HEIGHT = 18
COPPER_PASTELS_SWITCH_SPEED_MS = 1600


def palette_to_rgb(argb: int) -> tuple:
    """Convert ARGB uint32 to (r, g, b) tuple."""
    return ((argb >> 16) & 0xFF, (argb >> 8) & 0xFF, argb & 0xFF)


def rgb_to_argb(r: int, g: int, b: int) -> int:
    """Convert (r, g, b) to ARGB uint32."""
    return 0xFF000000 | (r << 16) | (g << 8) | b


def make_ehb_palette(palette: list) -> list:
    """Generate 64-entry palette with Extra Half-Brite entries."""
    pal = list(palette[:32])
    while len(pal) < 32:
        pal.append(0xFF000000)

    for i in range(32):
        c = pal[i]
        ehb = (0xFF000000
               | (((c & 0x00FF0000) >> 17) << 16)
               | (((c & 0x0000FF00) >> 9) << 8)
               | (((c & 0x000000FF) >> 1)))
        pal.append(ehb)
    return pal


def lerp_color(from_c: int, to_c: int, amt: float) -> int:
    """Interpolate between two ARGB colors."""
    r1, g1, b1 = (from_c >> 16) & 0xFF, (from_c >> 8) & 0xFF, from_c & 0xFF
    r2, g2, b2 = (to_c >> 16) & 0xFF, (to_c >> 8) & 0xFF, to_c & 0xFF

    r = int(r1 + (r2 - r1) * amt)
    g = int(g1 + (g2 - g1) * amt)
    b = int(b1 + (b2 - b1) * amt)

    return 0xFF000000 | (max(0, min(255, r)) << 16) | (max(0, min(255, g)) << 8) | max(0, min(255, b))


class CopperPastels:
    """Per-scanline color gradient effect emulating Amiga copper."""

    def __init__(self, ms_start: int, palette_fade_ref: int, pastels: list):
        """
        pastels: list of (tl, tr, bl, br) tuples where each is a color code char.
        """
        self.ms_start = ms_start
        self.palette_fade_ref = palette_fade_ref
        self.pastels = pastels
        self.num_pastels = len(pastels)
        self.colours = [0xFF000000] * (COPPER_PASTELS_WIDTH * COPPER_PASTELS_HEIGHT)

    def _code_to_colour(self, code: int, multiplier: int) -> int:
        c = chr(code) if isinstance(code, int) else code
        if c == 'W':
            return 0xFF000000 | (multiplier << 16) | (multiplier << 8) | multiplier
        elif c == 'R':
            return 0xFF000000 | (multiplier << 16)
        elif c == 'G':
            return 0xFF000000 | (multiplier << 8)
        elif c == 'B':
            return 0xFF000000 | multiplier
        elif c == 'Y':
            return 0xFF000000 | (multiplier << 16) | (multiplier << 8)
        elif c == 'X':
            return 0xFF000000
        return 0xFF000000

    def _interpolate_corner(self, first: int, second: int, amt: float, multiplier: int) -> int:
        c1 = self._code_to_colour(first, multiplier)
        c2 = self._code_to_colour(second, multiplier)
        return lerp_color(c1, c2, amt)

    def _set(self, x: int, y: int, colour: int):
        self.colours[y * COPPER_PASTELS_WIDTH + x] = colour

    def _get(self, x: int, y: int) -> int:
        return self.colours[y * COPPER_PASTELS_WIDTH + x]

    def tick(self, ms: int, get_palette_element=None):
        total_time = COPPER_PASTELS_SWITCH_SPEED_MS * self.num_pastels
        if total_time == 0:
            return
        ms_into = (ms - self.ms_start) % total_time
        amt = ms_into / COPPER_PASTELS_SWITCH_SPEED_MS
        first_idx = int(amt)
        amt -= first_idx
        second_idx = (first_idx + 1) % self.num_pastels

        if self.palette_fade_ref != -1 and get_palette_element is not None:
            ref = get_palette_element(self.palette_fade_ref)
            multiplier = (ref >> 16) & 0xFF
        else:
            multiplier = 0xFF

        first = self.pastels[first_idx]
        second = self.pastels[second_idx]

        # Set corners
        W = COPPER_PASTELS_WIDTH
        H = COPPER_PASTELS_HEIGHT
        self._set(0, 0, self._interpolate_corner(first[0], second[0], amt, multiplier))
        self._set(W - 1, 0, self._interpolate_corner(first[1], second[1], amt, multiplier))
        self._set(W - 1, H - 1, self._interpolate_corner(first[2], second[2], amt, multiplier))
        self._set(0, H - 1, self._interpolate_corner(first[3], second[3], amt, multiplier))

        # Interpolate top and bottom edges
        for x in range(1, W - 1):
            self._set(x, 0, lerp_color(self._get(0, 0), self._get(W - 1, 0), x / W))
            self._set(x, H - 1, lerp_color(self._get(0, H - 1), self._get(W - 1, H - 1), x / W))

        # Interpolate vertically
        for y_pos in range(1, H - 1):
            for x in range(W):
                self._set(x, y_pos, lerp_color(self._get(x, 0), self._get(x, H - 1), y_pos / H))

    def copper_effect(self, x: int, y: int, palette):
        """Called per scanline block to modify palette entries."""
        cy = y * COPPER_PASTELS_HEIGHT // 256
        cx = x * COPPER_PASTELS_WIDTH // 40
        cy = max(0, min(cy, COPPER_PASTELS_HEIGHT - 1))
        cx = max(0, min(cx, COPPER_PASTELS_WIDTH - 1))
        palette[0] = self._get(cx, cy)
        # Mirror effect for palette[2]
        mx = max(0, min(COPPER_PASTELS_WIDTH - cx, COPPER_PASTELS_WIDTH - 1))
        my = max(0, min(COPPER_PASTELS_HEIGHT - cy, COPPER_PASTELS_HEIGHT - 1))
        palette[2] = self._get(mx, my)
