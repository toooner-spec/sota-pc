"""Choreography/timeline scripting engine for State of the Art.

Parses and executes the binary choreography stream that drives the demo.
Each command has: start_ms (4B), length (4B), cmd (4B), then command-specific data.

Command types match nfd/sota's choreography_commands.h.
"""

import struct

from sota.graphics import Bitplane, copy_plane, lerp_palette
from sota.anim import AnimRenderer
from sota.iff import load_iff_from_data, display_iff

# Command IDs
CMD_END = 0
CMD_CLEAR = 1
CMD_PALETTE = 2
CMD_FADETO = 3
CMD_ANIM = 4
CMD_PAUSE = 5
CMD_MOD = 6
CMD_ILBM = 7
CMD_SOUND = 8
CMD_STARTEFFECT = 9
CMD_LOADFONT = 10
CMD_ALTERNATE_PALETTE = 11
CMD_USE_ALTERNATE_PALETTE = 12
CMD_SCENE = 13
CMD_SCENE_INDEX = 14
CMD_MBIT = 15
CMD_SCENE_OPTIONS = 16
CMD_MP3 = 17

# Sound sub-commands
SOUND_START = 1
SOUND_STOP = 2

# Effect IDs
EFFECT_NOTHING = 0
EFFECT_SPOTLIGHTS = 1
EFFECT_VOTEVOTEVOTE = 2
EFFECT_DELAYEDBLIT = 3
EFFECT_COPPERPASTELS = 4
EFFECT_STATIC = 5
EFFECT_STATIC2 = 6

# Bitplane styles
BITPLANE_OFF = 0
BITPLANE_1X1 = 1
BITPLANE_2X1 = 2
BITPLANE_2X2 = 3

# Scene option flags
SCENE_ONION_SKIN = 0x40
SCENE_OPTION_DISTORT = 1 << 15
SCENE_OPTION_FLIP_VERTICAL = 1 << 14
SCENE_OPTION_FLIP_HORIZONTAL = 1 << 13
SCENE_OPTION_OUTLINE = 1 << 12
SCENE_OPTION_ANIM_3_BEHIND = 1 << 11
SCENE_OPTION_EPILEPSY = 1 << 10
SCENE_OPTION_MULTIDRAW_3D = 1 << 9

ENDIAN = '<'


def parse_header(data: bytes, offset: int):
    """Parse a choreography command header: start_ms, length, cmd."""
    start_ms, length = struct.unpack_from(ENDIAN + 'II', data, offset)
    cmd = struct.unpack_from(ENDIAN + 'I', data, offset + 8)[0]
    return start_ms, length, cmd


class ChoreographyEngine:
    """Executes the choreography timeline to drive the demo."""

    def __init__(self, wad, window_width: int, window_height: int,
                 sound_player=None):
        self.wad = wad
        self.window_width = window_width
        self.window_height = window_height
        self.sound = sound_player

        # Animation renderer
        self.anim_renderer = AnimRenderer(window_width, window_height)

        # Bitplanes
        self.bitplanes = [None] * 6

        # Palette
        self.palette = [0xFF000000] * 32
        self.fade_from = [0xFF000000] * 32
        self.fade_to = [0xFF000000] * 32
        self.fade_count = 0
        self.fade_start_ms = 0
        self.fade_end_ms = 0

        self.alternate_palettes = [[0xFF000000] * 32, [0xFF000000] * 32]

        # Animation state
        self.current_animation = None
        self.current_anim_info = None
        self.animation_running = False
        self.last_drawn_frame = 0xFFFF
        self.backwards_subtract = 0
        self.ms_per_anim_frame = 40
        self.post_anim_clear_mask = 0
        self.first_frame_copy_mask = 0
        self.onion_skin = False
        self.onion_skin_low = 0
        self.onion_skin_high = 0
        self.anim_bitplane = 0
        self.anim_3_behind = False
        self.epilepsy = False
        self.epilepsy_last_frame = False

        # Pause
        self.pause_end_ms = 0

        # Effects
        self.effect_tick = None
        self.effect_deinit = None

        # Copper
        self.copper_func = None

        # Choreography data
        self.choreo_data = None
        self.pos = 0
        self.end_of_demo_flag = False

        # Font stubs
        self.font_draw = None
        self.font_height = lambda: 16

        # IFF image loader stub
        self.iff_loader = None

    def allocate_bitplane(self, idx: int, width: int, height: int):
        self.bitplanes[idx] = Bitplane(idx, width, height)

    def set_new_scene(self):
        for i in range(6):
            self.bitplanes[i] = None

    def set_palette(self, values: list):
        """Set palette, automatically generating EHB entries."""
        for i in range(min(len(values), 32)):
            self.palette[i] = values[i]
        for i in range(len(values), 32):
            self.palette[i] = 0xFF000000

    def get_palette(self) -> list:
        return list(self.palette[:32])

    def get_palette_element(self, idx: int) -> int:
        if 0 <= idx < 32:
            return self.palette[idx]
        return 0xFF000000

    def set_palette_element(self, idx: int, value: int):
        if 0 <= idx < 32:
            self.palette[idx] = value

    def register_copper_func(self, func):
        self.copper_func = func

    def prepare_to_run(self, start_ms: int = 0):
        """Load and prepare choreography data, seeking to start_ms."""
        choreo_raw = self.wad.get_choreography()
        self.choreo_data = choreo_raw
        self.pos = 0

        # Skip scene index if present
        if len(self.choreo_data) >= 12:
            _, _, cmd = parse_header(self.choreo_data, 0)
            if cmd == CMD_SCENE_INDEX:
                _, length, _ = parse_header(self.choreo_data, 0)
                self.pos = length

        # Skip to start_ms
        if start_ms > 0:
            self._skip_to(start_ms)

    def _skip_to(self, ms: int):
        """Fast-forward to the given time, executing all commands up to that point."""
        while self.pos < len(self.choreo_data) - 12:
            start_ms, length, cmd = parse_header(self.choreo_data, self.pos)
            if start_ms >= ms or cmd == CMD_END:
                break
            self._execute_command(ms)
            self.pos += length

    def do_frame(self, ms: int) -> bool:
        """Process one frame at the given time. Returns True if end of scene/demo."""
        self._create_new_state(ms)
        self._run(ms)

        if self.pos < len(self.choreo_data) - 8:
            _, _, cmd = parse_header(self.choreo_data, self.pos)
            if cmd == CMD_END:
                end_val = struct.unpack_from(ENDIAN + 'I', self.choreo_data, self.pos + 12)[0]
                if end_val == 0:
                    self.end_of_demo_flag = True
                return True
        return False

    def _create_new_state(self, ms: int):
        """Execute all commands whose start_ms <= current time."""
        while self.pos < len(self.choreo_data) - 8:
            start_ms, length, cmd = parse_header(self.choreo_data, self.pos)

            if cmd == CMD_END:
                end_val = struct.unpack_from(ENDIAN + 'I', self.choreo_data, self.pos + 12)[0]
                if end_val == 0:
                    self.end_of_demo_flag = True
                    return
                # End of scene marker, advance past it
                if start_ms <= ms:
                    self.pos += length
                    continue
                return

            if start_ms > ms:
                return

            self._execute_command(ms)
            self.pos += length

    def _execute_command(self, ms: int):
        """Execute the command at the current position."""
        if self.pos + 12 > len(self.choreo_data):
            return

        start_ms, length, cmd = parse_header(self.choreo_data, self.pos)
        data = self.choreo_data
        base = self.pos + 12  # after header (start_ms, length, cmd)

        if cmd == CMD_CLEAR:
            plane = struct.unpack_from(ENDIAN + 'I', data, base)[0]
            if plane == 0xFF:
                for bp in self.bitplanes:
                    if bp is not None:
                        bp.clear()
            elif 0 <= plane < 6 and self.bitplanes[plane] is not None:
                self.bitplanes[plane].clear()

        elif cmd == CMD_PALETTE:
            count = struct.unpack_from(ENDIAN + 'I', data, base)[0]
            values = []
            for i in range(min(count, 32)):
                values.append(struct.unpack_from(ENDIAN + 'I', data, base + 4 + i * 4)[0])
            self.fade_count = 0
            self.set_palette(values)

        elif cmd == CMD_ALTERNATE_PALETTE:
            alt_idx = struct.unpack_from(ENDIAN + 'I', data, base)[0]
            values = []
            for i in range(32):
                values.append(struct.unpack_from(ENDIAN + 'I', data, base + 4 + i * 4)[0])
            if 0 <= alt_idx <= 1:
                self.alternate_palettes[alt_idx] = values

        elif cmd == CMD_USE_ALTERNATE_PALETTE:
            alt_idx = struct.unpack_from(ENDIAN + 'I', data, base)[0]
            if 0 <= alt_idx <= 1:
                self.set_palette(self.alternate_palettes[alt_idx])

        elif cmd == CMD_FADETO:
            fade_ms = struct.unpack_from(ENDIAN + 'I', data, base)[0]
            # Parse the embedded palette command
            pal_count = struct.unpack_from(ENDIAN + 'I', data, base + 8)[0]
            values = []
            for i in range(min(pal_count, 32)):
                values.append(struct.unpack_from(ENDIAN + 'I', data, base + 12 + i * 4)[0])

            self.fade_from = self.get_palette()
            self.fade_to = values + [0xFF000000] * (32 - len(values))
            self.fade_count = min(pal_count, 32)
            self.fade_start_ms = start_ms
            self.fade_end_ms = start_ms + fade_ms

        elif cmd == CMD_ANIM:
            data_file = struct.unpack_from(ENDIAN + 'I', data, base)[0]
            frame_from, frame_to, bitplane, xor_val = struct.unpack_from(
                ENDIAN + 'HHHH', data, base + 4
            )

            self.current_animation = self.anim_renderer.load_anim(self.wad, data_file)
            self.current_anim_info = {
                'start_ms': start_ms,
                'data_file': data_file,
                'frame_from': frame_from,
                'frame_to': frame_to,
                'bitplane': bitplane,
                'xor': xor_val,
            }
            self.last_drawn_frame = 0xFFFF
            self.animation_running = True

            if frame_from > frame_to:
                self.backwards_subtract = frame_from + frame_to
                self.current_anim_info['frame_from'] = frame_to
                self.current_anim_info['frame_to'] = frame_from
            else:
                self.backwards_subtract = 0

            self.anim_bitplane = bitplane
            self.anim_renderer.set_xor(bool(xor_val))

        elif cmd == CMD_PAUSE:
            end_ms = struct.unpack_from(ENDIAN + 'I', data, base)[0]
            # pause end is relative: start_ms + pause duration
            # Actually in build_demo.py, the pause end is just the duration added to timeline
            # The actual end ms is embedded after CMD_PAUSE
            self.pause_end_ms = start_ms + end_ms if end_ms < 100000 else end_ms

        elif cmd == CMD_MOD or cmd == CMD_MP3:
            subcmd = struct.unpack_from(ENDIAN + 'I', data, base)[0]
            arg = struct.unpack_from(ENDIAN + 'I', data, base + 4)[0]
            if self.sound is not None:
                if subcmd == SOUND_START:
                    self.sound.play_mod(self.wad, arg)
                elif subcmd == SOUND_STOP:
                    self.sound.stop_mod()

        elif cmd == CMD_SOUND:
            file_idx = struct.unpack_from(ENDIAN + 'I', data, base)[0]
            if self.sound is not None:
                self.sound.play_sample(self.wad, file_idx)

        elif cmd == CMD_STARTEFFECT:
            effect_num = struct.unpack_from(ENDIAN + 'I', data, base)[0]
            self._start_effect(ms, effect_num, data, base + 4, length - 16)

        elif cmd == CMD_SCENE:
            self._cmd_scene(ms, data, base)

        elif cmd == CMD_SCENE_OPTIONS:
            zoom, flags = struct.unpack_from(ENDIAN + 'HH', data, base)
            self._cmd_scene_options(zoom, flags)

        elif cmd == CMD_SCENE_INDEX:
            pass  # Handled during prepare

        elif cmd == CMD_ILBM:
            file_idx = struct.unpack_from(ENDIAN + 'I', data, base)[0]
            x, y, w, h = data[base + 4], data[base + 5], data[base + 6], data[base + 7]
            fade_in_ms = struct.unpack_from(ENDIAN + 'I', data, base + 8)[0]
            plane_idx = struct.unpack_from(ENDIAN + 'I', data, base + 12)[0]
            self._cmd_ilbm(file_idx, x, y, w, h, fade_in_ms, plane_idx, start_ms)

        elif cmd == CMD_LOADFONT:
            # Font loading stub
            pass

        elif cmd == CMD_MBIT:
            pass  # MBIT format not used in standard demo

    def _cmd_scene(self, ms: int, data: bytes, base: int):
        """Handle scene command: allocate bitplanes and set parameters."""
        # Deinit any active effect and clear copper from previous scene
        if self.effect_deinit is not None:
            self.effect_deinit()
            self.effect_tick = None
            self.effect_deinit = None
        self.copper_func = None

        self.set_new_scene()

        # Reset animation state for the new scene
        self.animation_running = False
        self.last_drawn_frame = 0xFFFF
        self.fade_count = 0

        plane_styles = [data[base + i] for i in range(6)]
        msperframe = data[base + 6]
        onion_high = data[base + 7]
        onion_low = data[base + 8]
        post_clear_mask = data[base + 9]
        first_copy_mask = data[base + 10]

        for i in range(6):
            style = plane_styles[i]
            if style == BITPLANE_OFF:
                continue
            elif style == BITPLANE_1X1:
                self.allocate_bitplane(i, self.window_width, self.window_height)
            elif style == BITPLANE_2X1:
                self.allocate_bitplane(i, self.window_width * 2, self.window_height)
            elif style == BITPLANE_2X2:
                self.allocate_bitplane(i, self.window_width * 2, self.window_height * 2)

        self.ms_per_anim_frame = msperframe if msperframe > 0 else 40
        self.post_anim_clear_mask = post_clear_mask
        self.first_frame_copy_mask = first_copy_mask
        self.onion_skin = bool(onion_high & SCENE_ONION_SKIN)
        self.onion_skin_low = onion_high & 0x3F
        self.onion_skin_high = onion_low & 0xFF
        self.anim_bitplane = 0

        # Reset scene options to defaults
        self._cmd_scene_options(1, 0)

    def _cmd_ilbm(self, file_idx: int, x: int, y: int, w: int, h: int,
                  fade_in_ms: int, plane_idx: int, start_ms: int):
        """Load and display an IFF ILBM image."""
        try:
            iff_data_raw = self.wad.get_file(file_idx)
            iff = load_iff_from_data(iff_data_raw)
            if iff is None:
                return

            iff_palette = display_iff(iff, x, y, w, h, self.bitplanes, plane_idx)

            if fade_in_ms == 0:
                # Immediate palette set — also cancel any pending fade
                # (matches C reference: state.fade_count = 0)
                if iff_palette:
                    self.set_palette(iff_palette)
                self.fade_count = 0
            else:
                # Fade to IFF palette
                if iff_palette:
                    self.fade_from = self.get_palette()
                    self.fade_to = list(iff_palette)
                    while len(self.fade_to) < 32:
                        self.fade_to.append(0xFF000000)
                    self.fade_count = min(len(iff_palette), 32)
                    self.fade_start_ms = start_ms
                    self.fade_end_ms = start_ms + fade_in_ms
        except Exception:
            pass  # Gracefully handle missing/corrupt IFF data

    def _cmd_scene_options(self, zoom: int, flags: int):
        self.anim_renderer.set_zoom(zoom)
        self.anim_renderer.set_distort(bool(flags & SCENE_OPTION_DISTORT))
        self.anim_renderer.set_flip(
            bool(flags & SCENE_OPTION_FLIP_HORIZONTAL),
            bool(flags & SCENE_OPTION_FLIP_VERTICAL)
        )
        self.anim_renderer.set_outline(bool(flags & SCENE_OPTION_OUTLINE))
        self.anim_3_behind = bool(flags & SCENE_OPTION_ANIM_3_BEHIND)
        self.epilepsy = bool(flags & SCENE_OPTION_EPILEPSY)
        self.anim_renderer.set_multidraw_3d(bool(flags & SCENE_OPTION_MULTIDRAW_3D))
        self.epilepsy_last_frame = False

    def _start_effect(self, ms: int, effect_num: int, data: bytes, offset: int, extra_len: int):
        """Initialize a visual effect."""
        from sota.scene import (
            SpotlightsEffect, VoteVoteVoteEffect, DelayedBlitEffect,
            CopperPastelsEffect, StaticEffect, Static2Effect
        )

        if self.effect_deinit is not None:
            self.effect_deinit()
            self.effect_tick = None
            self.effect_deinit = None

        if effect_num == EFFECT_NOTHING:
            return

        elif effect_num == EFFECT_SPOTLIGHTS:
            effect = SpotlightsEffect(self.bitplanes, self.window_width, self.window_height)
            self.effect_tick = effect.tick
            self.effect_deinit = effect.deinit

        elif effect_num == EFFECT_VOTEVOTEVOTE:
            # Parse text block
            text_block = self._parse_text_block(data, offset)
            effect = VoteVoteVoteEffect(
                text_block, self.alternate_palettes[0], self.alternate_palettes[1],
                self.bitplanes, self.font_draw, self.font_height
            )
            self.effect_tick = lambda ms: effect.tick(ms, self.set_palette)
            self.effect_deinit = effect.deinit

        elif effect_num == EFFECT_DELAYEDBLIT:
            effect = DelayedBlitEffect(self.bitplanes, copy_plane)
            self.effect_tick = effect.tick
            self.effect_deinit = effect.deinit

        elif effect_num == EFFECT_COPPERPASTELS:
            pastels_data = self._parse_copper_pastels(data, offset)
            effect = CopperPastelsEffect(
                ms, pastels_data['palette_fade_ref'], pastels_data['pastels'],
                self.register_copper_func
            )
            self.effect_tick = lambda ms: effect.tick(ms, self.get_palette_element)
            self.effect_deinit = effect.deinit

        elif effect_num == EFFECT_STATIC:
            effect = StaticEffect(ms, self.bitplanes, self.window_width, self.window_height)
            self.effect_tick = effect.tick
            self.effect_deinit = effect.deinit

        elif effect_num == EFFECT_STATIC2:
            effect = Static2Effect(ms, self.bitplanes, self.window_width, self.window_height)
            self.effect_tick = effect.tick
            self.effect_deinit = effect.deinit

    def _parse_text_block(self, data: bytes, offset: int) -> list:
        """Parse votevotevote text block."""
        try:
            block_len, num_entries = struct.unpack_from(ENDIAN + 'II', data, offset)
            texts = []
            indices_start = offset + 8
            for i in range(num_entries):
                pos_i = struct.unpack_from(ENDIAN + 'H', data, indices_start + i * 2)[0]
                pos_next = struct.unpack_from(ENDIAN + 'H', data, indices_start + (i + 1) * 2)[0]
                text_start = indices_start + pos_i
                text_len = pos_next - pos_i
                texts.append(data[text_start:text_start + text_len].decode('utf-8', errors='replace'))
            return texts
        except Exception:
            return ['VOTE!'] * 22

    def _parse_copper_pastels(self, data: bytes, offset: int) -> dict:
        """Parse copper pastels effect data."""
        try:
            palette_fade_ref, num_pastels = struct.unpack_from(ENDIAN + 'hH', data, offset)
            pastels = []
            for i in range(num_pastels):
                p = data[offset + 4 + i * 4:offset + 4 + (i + 1) * 4]
                pastels.append((chr(p[0]), chr(p[1]), chr(p[2]), chr(p[3])))
            return {'palette_fade_ref': palette_fade_ref, 'pastels': pastels}
        except Exception:
            return {'palette_fade_ref': -1, 'pastels': [('W', 'W', 'W', 'W')]}

    def _run(self, ms: int):
        """Run the per-frame update: animation, fades, effects."""
        # Animation
        if self.animation_running and self.current_anim_info is not None:
            anim_start = self.current_anim_info['start_ms']
            frame_offset = (ms - anim_start) // self.ms_per_anim_frame
            anim_frame = frame_offset + self.current_anim_info['frame_from']

            if anim_frame > self.current_anim_info['frame_to']:
                self.animation_running = False
                self._clear_masked_planes(self.post_anim_clear_mask)
            else:
                if self.last_drawn_frame != anim_frame:
                    # Onion skinning
                    if self.onion_skin:
                        high = self.onion_skin_high
                        low = self.onion_skin_low
                        if high < len(self.bitplanes) and low < len(self.bitplanes):
                            tmp = self.bitplanes[high]
                            for i in range(high, low, -1):
                                self.bitplanes[i] = self.bitplanes[i - 1]
                            self.bitplanes[low] = tmp

                    self.last_drawn_frame = anim_frame

                    real_frame = (self.backwards_subtract - anim_frame
                                  if self.backwards_subtract else anim_frame)

                    bp_idx = self.anim_bitplane
                    if bp_idx < len(self.bitplanes) and self.bitplanes[bp_idx] is not None:
                        self.anim_renderer._target_plane = self.bitplanes[bp_idx]
                        self.anim_renderer.draw_to_plane(
                            self.bitplanes[bp_idx], self.current_animation, real_frame,
                            self.bitplanes
                        )

                    if self.anim_3_behind and len(self.bitplanes) > 1 and self.bitplanes[1] is not None:
                        delayed = max(0, real_frame - 3)
                        self.anim_renderer.draw_to_plane(
                            self.bitplanes[1], self.current_animation, delayed,
                            self.bitplanes
                        )

                    if anim_frame == self.current_anim_info['frame_from']:
                        self._copy_planes_masked(bp_idx, self.first_frame_copy_mask)

        # Palette fades
        if self.fade_count > 0:
            if ms > self.fade_end_ms:
                self.set_palette(self.fade_to)
                self.fade_count = 0
            else:
                elapsed = ms - self.fade_start_ms
                total = self.fade_end_ms - self.fade_start_ms
                lerped = lerp_palette(self.fade_count, self.fade_from, self.fade_to,
                                      elapsed, total)
                for i, c in enumerate(lerped):
                    self.palette[i] = c

        # Effects
        if self.effect_tick is not None:
            self.effect_tick(ms)

        # Epilepsy strobe (the final dancing scene)
        # Only toggle on animation frame boundaries to match original Amiga timing
        if self.epilepsy:
            if self.animation_running and self.current_anim_info is not None:
                anim_start = self.current_anim_info['start_ms']
                frame_offset = (ms - anim_start) // self.ms_per_anim_frame
                strobe_on = (frame_offset % 2) == 0
            else:
                strobe_on = not self.epilepsy_last_frame
            if strobe_on:
                self.set_palette([0xFF000000] * 32)
            elif self.fade_count == 0:
                self.set_palette(self.fade_to)
            self.epilepsy_last_frame = strobe_on

    def _clear_masked_planes(self, mask: int):
        for i in range(6):
            if mask & (1 << i) and self.bitplanes[i] is not None:
                self.bitplanes[i].clear()

    def _copy_planes_masked(self, src_plane: int, mask: int):
        if src_plane >= len(self.bitplanes) or self.bitplanes[src_plane] is None:
            return
        src = self.bitplanes[src_plane]
        for i in range(6):
            if (mask & (1 << i)) and self.bitplanes[i] is not None:
                copy_plane(src, self.bitplanes[i])
