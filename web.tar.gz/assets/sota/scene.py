"""Scene effects for State of the Art.

Implements the 6 visual effects from the demo:
1. Spotlights - Moving concentric circles
2. VoteVoteVote - Rotating text display
3. Delayed Blit - Cascading bitplane copy
4. Copper Pastels - Per-scanline color gradients
5. Static - Random noise with circles
6. Static2 - Rectangle noise with viewport shifting
"""

import math
import random
import struct
from sota.graphics import (
    Bitplane, draw_thick_circle, draw_circle,
    line_horizontal, line_vertical, copy_plane
)
from sota.palette import CopperPastels

VOTEVOTEVOTE_DISPLAY_MS = 60
STATIC_SWITCH_SPEED_TICKS = 2


class PCGRandom:
    """PCG32 random number generator for deterministic static effects."""
    def __init__(self, state=0x57a7e0fa27, inc=37):
        self.state = state & 0xFFFFFFFFFFFFFFFF
        self.inc = inc

    def next(self) -> int:
        old_state = self.state
        self.state = (old_state * 6364136223846793005 + (self.inc | 1)) & 0xFFFFFFFFFFFFFFFF
        xorshifted = (((old_state >> 18) ^ old_state) >> 27) & 0xFFFFFFFF
        rot = (old_state >> 59) & 0x1F
        return ((xorshifted >> rot) | (xorshifted << (32 - rot))) & 0xFFFFFFFF


class SpotlightsEffect:
    """Concentric circles moving on sine-wave paths."""

    def __init__(self, bitplanes: list, window_width: int, window_height: int):
        self.bitplanes = bitplanes
        self.w = window_width
        self.h = window_height

        scale_x = window_width / 256
        scale_y = window_height / 256
        global_scale = max(scale_x, scale_y)

        thickness = max(4, int(4 * global_scale))
        gap = (2 * thickness) // 3

        longest = int(math.sqrt(window_width ** 2 + window_height ** 2))

        # Draw concentric circles pattern on plane 1
        # Plane 2 shares data with plane 1 (viewport shifting)
        bp1 = bitplanes[1]
        if bp1 is not None:
            radius = thickness
            while radius < longest:
                draw_thick_circle(bp1, window_width, window_height, radius, thickness)
                radius += thickness + gap

            # Plane 2 is a viewport into plane 1's data
            if bitplanes[2] is not None:
                bitplanes[2].data = bp1.data
                bitplanes[2].stride = bp1.stride

        self.scale_x = scale_x
        self.scale_y = scale_y

    def tick(self, ms: int):
        cnt = ms
        # Spotlight 1: trails across screen
        offset_x = int((128 + 128 * math.sin(cnt / 800)) * self.scale_x)
        offset_y = int((128 + 128 * math.sin(cnt / 2000)) * self.scale_y)
        bp1 = self.bitplanes[1]
        if bp1 is not None:
            bp1.data_offset = offset_y * bp1.stride + offset_x // 8

        # Spotlight 2: moves vertically
        offset_x2 = int(30 * self.scale_x)
        offset_y2 = int((128 + 128 * math.sin(1.0 + cnt / 1200)) * self.scale_y)
        bp2 = self.bitplanes[2]
        if bp2 is not None:
            bp2.data_offset = offset_y2 * bp2.stride + offset_x2 // 8

    def deinit(self):
        pass


class VoteVoteVoteEffect:
    """Rotating random text display with palette alternation."""

    def __init__(self, text_block: list, palette_a: list, palette_b: list,
                 bitplanes: list, font_draw_func, font_height_func):
        self.text_block = text_block
        self.palette_a = palette_a
        self.palette_b = palette_b
        self.bitplanes = bitplanes
        self.font_draw = font_draw_func
        self.font_height = font_height_func
        self.last_ms = 0
        self.last_palette = 0

        # Split text into 3 lines
        self.bot_count = 4
        self.top_count = (len(text_block) - 4) // 2
        self.mid_count = self.top_count
        self.prev_top = -1
        self.prev_mid = -1
        self.prev_bot = -1

    def tick(self, ms: int, set_palette_func):
        if self.last_ms + VOTEVOTEVOTE_DISPLAY_MS > ms:
            return

        # Clear planes 0-2
        for i in range(min(3, len(self.bitplanes))):
            if self.bitplanes[i] is not None:
                self.bitplanes[i].clear()

        top_idx = random.randint(0, self.top_count - 1)
        mid_idx = random.randint(0, self.mid_count - 1)
        bot_idx = random.randint(0, self.bot_count - 1)

        if top_idx == self.prev_top:
            top_idx = (top_idx + 1) % self.top_count
        if mid_idx == self.prev_mid:
            mid_idx = (mid_idx + 1) % self.mid_count
        if bot_idx == self.prev_bot:
            bot_idx = (bot_idx + 1) % self.bot_count

        # Alternate palettes
        if self.last_palette == 1:
            set_palette_func(self.palette_a)
        else:
            set_palette_func(self.palette_b)
        self.last_palette = 1 - self.last_palette

        fh = self.font_height() if self.font_height else 16
        base_y = (self.bitplanes[0].height // 2) - (fh // 2) - fh

        if self.font_draw:
            self.font_draw(self.text_block[top_idx], -1, base_y)
            self.font_draw(self.text_block[self.top_count + mid_idx], -1, base_y + fh)
            self.font_draw(self.text_block[self.top_count + self.mid_count + bot_idx], -1, base_y + 2 * fh)

        self.last_ms = ms
        self.prev_top = top_idx
        self.prev_mid = mid_idx
        self.prev_bot = bot_idx

    def deinit(self):
        pass


class DelayedBlitEffect:
    """Cascading bitplane copy effect."""

    def __init__(self, bitplanes: list, copy_func):
        self.bitplanes = bitplanes
        self.copy_func = copy_func
        self.delay = 80
        self.next_blit = 0

    def tick(self, ms: int):
        if ms < self.next_blit:
            return

        # Copy planes downward: plane[4] -> plane[3] -> ... -> plane[1] -> plane[0]
        for plane_idx in range(4, 0, -1):
            if (plane_idx < len(self.bitplanes)
                    and self.bitplanes[plane_idx] is not None
                    and self.bitplanes[plane_idx - 1] is not None):
                copy_plane(self.bitplanes[plane_idx], self.bitplanes[plane_idx - 1])

        self.next_blit += self.delay

    def deinit(self):
        pass


class CopperPastelsEffect:
    """Per-scanline color gradient interpolation effect."""

    def __init__(self, ms: int, palette_fade_ref: int, pastels: list,
                 register_copper_func):
        self.copper = CopperPastels(ms, palette_fade_ref, pastels)
        self.register_copper = register_copper_func
        register_copper_func(self.copper.copper_effect)

    def tick(self, ms: int, get_palette_element=None):
        self.copper.tick(ms, get_palette_element)

    def deinit(self):
        self.register_copper(None)


class StaticEffect:
    """Random noise with circle overlays."""

    CIRCLE_RADII = [25, 64, 50, 88, 75, 115, 105, 135]
    NUM_FRAMES = 4

    def __init__(self, ms: int, bitplanes: list, window_width: int, window_height: int):
        self.bitplanes = bitplanes
        self.w = window_width
        self.h = window_height
        self.ticks = 0
        self.rng = PCGRandom(state=0x57a7e0fa27)
        self.global_scale = max(window_width / 256, window_height / 256)

    def tick(self, ms: int):
        if self.ticks % STATIC_SWITCH_SPEED_TICKS == 0:
            frame = (self.ticks // STATIC_SWITCH_SPEED_TICKS) % self.NUM_FRAMES
            self.rng.inc = 37 + frame

            plane = self.bitplanes[0]
            if plane is None:
                self.ticks += 1
                return

            # Fill with random noise
            for y_pos in range(plane.height):
                for x_byte in range(plane.stride):
                    rval = self.rng.next()
                    idx = y_pos * plane.stride + x_byte + plane.data_offset
                    if idx < len(plane.data):
                        plane.data[idx] = rval & 0xFF

            # Draw circles
            radii_idx = frame * 2
            for ri in range(radii_idx, min(radii_idx + 2, len(self.CIRCLE_RADII))):
                radius = int(self.CIRCLE_RADII[ri] * self.global_scale)
                cx, cy = self.w // 2, self.h // 2
                gs = int(self.global_scale)
                draw_circle(plane, cx, cy, radius)
                draw_circle(plane, 4 * gs + cx, cy, radius)
                draw_circle(plane, cx, 4 * gs + cy, radius)
                draw_circle(plane, 2 * gs + cx, 2 * gs + cy, radius)

            # Delayed blit copy
            for pi in range(3, 1, -1):
                if (pi < len(self.bitplanes)
                        and self.bitplanes[pi] is not None
                        and self.bitplanes[pi - 1] is not None):
                    copy_plane(self.bitplanes[pi], self.bitplanes[pi - 1])

        self.ticks += 1

    def deinit(self):
        pass


class Static2Effect:
    """Rectangular noise with viewport shifting."""

    def __init__(self, ms: int, bitplanes: list, window_width: int, window_height: int):
        self.bitplanes = bitplanes
        self.w = window_width
        self.h = window_height
        self.ticks = 0
        self.bp_idx = 5  # STATIC2_BITPLANE_NUM

    def tick(self, ms: int):
        if self.bp_idx >= len(self.bitplanes) or self.bitplanes[self.bp_idx] is None:
            self.ticks += 1
            return

        bp = self.bitplanes[self.bp_idx]
        half_w_bytes = bp.stride // 2
        half_h_bytes = (bp.height // 2) * bp.stride

        quadrant = (self.ticks % 16) >> 2
        if quadrant == 0:
            bp.data_offset = 0
        elif quadrant == 1:
            bp.data_offset = half_w_bytes
        elif quadrant == 2:
            bp.data_offset = half_h_bytes
        elif quadrant == 3:
            bp.data_offset = half_h_bytes + half_w_bytes

        self.ticks += 1

    def deinit(self):
        pass
