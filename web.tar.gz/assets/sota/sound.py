"""Music and sound playback for State of the Art.

Supports MOD tracker format playback via pygame.mixer.music.
Falls back to silence if audio files aren't available.
"""

import os
import tempfile
import pygame


class SoundPlayer:
    """Handles MOD music and WAV sample playback."""

    def __init__(self):
        self.initialized = False
        self.mod_playing = False
        self.mod_start_ms = 0
        self._temp_files = []

        try:
            pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=2048)
            self.initialized = True
        except pygame.error as e:
            print(f"Sound init failed: {e}")

    def play_mod(self, wad, file_idx: int):
        """Extract MOD from WAD and play it."""
        if not self.initialized:
            return

        try:
            mod_data = wad.get_file(file_idx)
            # Write to temp file (pygame needs a file path)
            tmp = tempfile.NamedTemporaryFile(suffix='.mod', delete=False)
            tmp.write(mod_data)
            tmp.close()
            self._temp_files.append(tmp.name)

            pygame.mixer.music.load(tmp.name)
            pygame.mixer.music.play()
            self.mod_playing = True
            self.mod_start_ms = pygame.time.get_ticks()
        except Exception as e:
            print(f"MOD play failed: {e}")

    def stop_mod(self):
        if not self.initialized:
            return
        try:
            pygame.mixer.music.stop()
        except Exception:
            pass
        self.mod_playing = False

    def play_sample(self, wad, file_idx: int):
        """Play a WAV sample from the WAD."""
        if not self.initialized:
            return

        try:
            sample_data = wad.get_file(file_idx)
            tmp = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
            tmp.write(sample_data)
            tmp.close()
            self._temp_files.append(tmp.name)

            sound = pygame.mixer.Sound(tmp.name)
            sound.play()
        except Exception as e:
            print(f"Sample play failed: {e}")

    def get_position_ms(self) -> int:
        """Get current music playback position in milliseconds."""
        if not self.initialized or not self.mod_playing:
            return 0
        try:
            pos = pygame.mixer.music.get_pos()
            return max(0, pos)
        except Exception:
            return 0

    def update(self):
        """Called each frame for sound updates."""
        pass

    def shutdown(self):
        """Clean up temp files and mixer."""
        try:
            pygame.mixer.quit()
        except Exception:
            pass

        for f in self._temp_files:
            try:
                os.unlink(f)
            except Exception:
                pass
        self._temp_files.clear()
