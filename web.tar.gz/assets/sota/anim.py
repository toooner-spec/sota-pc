"""Animation data parser and renderer for State of the Art.

Animation file format (from nfd/sota):
- 2 bytes: number of frame indices (big-endian)
- indices section: frame_count * 2 bytes of big-endian offsets
- data section: drawing commands per frame

Draw commands:
- 0xD0 series: Polygon draw. Byte: command, vertex count, then (y, x) pairs
- 0xE0/0xF0 series: Tweened animation. References two shapes and interpolates.
"""

from sota.graphics import (
    Bitplane, draw_filled_scaled_polygon, draw_scaled_polygon_outline
)

ANIM_SOURCE_WIDTH = 256
ANIM_SOURCE_HEIGHT = 200
MAX_TWEENED_VERTICES = 512


class Animation:
    """Parsed animation data with frame index and drawing commands."""

    def __init__(self, data: bytes, data_file_idx: int):
        self.data_file = data_file_idx
        self.raw_data = data
        self.num_frames = (data[0] << 8) | data[1]
        self.indices_start = 2
        self.data_start = self.indices_start + (self.num_frames * 2)

    def get_frame_offset(self, frame_idx: int) -> int:
        """Get the byte offset of frame_idx's data within the data section."""
        idx_pos = self.indices_start + (frame_idx * 2)
        return (self.raw_data[idx_pos] << 8) | self.raw_data[idx_pos + 1]


class AnimRenderer:
    """Manages animation state and rendering."""

    def __init__(self, window_width: int, window_height: int):
        self.window_width = window_width
        self.window_height = window_height

        self.scale_x = window_width / ANIM_SOURCE_WIDTH
        self.scale_y = window_height / ANIM_SOURCE_HEIGHT
        self.zoom = 1
        self.offset_x = 0
        self.offset_y = 0

        self.xor_mode = True
        self.distort = False
        self.flip_horizontal = False
        self.flip_vertical = False
        self.outline = False
        self.multidraw_3d = False

        self.outline_width = max(2, (2 * max(320, window_width)) // 320)

        self.current_anim = None
        self.prev_anim = None

        self._tween_buffer = bytearray(MAX_TWEENED_VERTICES * 2 + 1)

        self._recalc_offset()

    def _recalc_offset(self):
        self.offset_x = (self.window_width // 2) - int(
            (ANIM_SOURCE_WIDTH * self.scale_x * self.zoom) / 2
        )
        if self.zoom == 1:
            self.offset_y = self.window_height - int(ANIM_SOURCE_HEIGHT * self.scale_y)
        else:
            self.offset_y = self.window_height - int(
                ANIM_SOURCE_HEIGHT * self.scale_y * self.zoom * 3 / 4
            )

    def set_zoom(self, zoom: int):
        self.zoom = zoom
        self._recalc_offset()

    def set_xor(self, enabled: bool):
        self.xor_mode = enabled

    def set_distort(self, enabled: bool):
        self.distort = enabled

    def set_flip(self, horizontal: bool, vertical: bool):
        self.flip_horizontal = horizontal
        self.flip_vertical = vertical

    def set_outline(self, enabled: bool):
        self.outline = enabled

    def set_multidraw_3d(self, enabled: bool):
        self.multidraw_3d = enabled

    def load_anim(self, wad, data_file_idx: int) -> Animation:
        """Load animation data from WAD file."""
        file_data = wad.get_file(data_file_idx)
        if self.current_anim is not None and self.current_anim.data_file != data_file_idx:
            self.prev_anim = self.current_anim
        self.current_anim = Animation(file_data, data_file_idx)
        return self.current_anim

    def draw(self, bitplanes: list, anim: Animation, frame_idx: int):
        """Draw a single animation frame to the target bitplane(s)."""
        if frame_idx > anim.num_frames:
            return

        data_offset = anim.get_frame_offset(frame_idx)
        data = anim.raw_data
        pos = anim.data_start + data_offset

        num_objects = data[pos]
        pos += 1
        if num_objects < 1 or num_objects > 16:
            return

        # Clear target planes
        if self.multidraw_3d:
            for i in range(3):
                if bitplanes[i] is not None:
                    bitplanes[i].clear()
        else:
            target = bitplanes[0] if not hasattr(self, '_target_plane') else self._target_plane
            if target is not None:
                target.clear()

        for _ in range(num_objects):
            pos = self._draw_object(bitplanes, data, pos, anim)

    def draw_to_plane(self, plane: Bitplane, anim: Animation, frame_idx: int, bitplanes: list):
        """Draw animation frame to a specific bitplane."""
        self._target_plane = plane
        if frame_idx > anim.num_frames:
            return

        data_offset = anim.get_frame_offset(frame_idx)
        data = anim.raw_data
        pos = anim.data_start + data_offset

        num_objects = data[pos]
        pos += 1
        if num_objects < 1 or num_objects > 16:
            return

        if self.multidraw_3d:
            for i in range(3):
                if bitplanes[i] is not None:
                    bitplanes[i].clear()
        else:
            plane.clear()

        for _ in range(num_objects):
            pos = self._draw_object(bitplanes, data, pos, anim)

    def _draw_object(self, bitplanes: list, data: bytes, pos: int, anim: Animation) -> int:
        """Draw a single object. Returns new position in data."""
        draw_cmd = data[pos]
        pos += 1

        cmd_type = draw_cmd & 0xF0
        scalex = self.zoom * self.scale_x
        scaley = self.zoom * self.scale_y
        ox = self.offset_x
        oy = self.offset_y

        target_plane = getattr(self, '_target_plane', bitplanes[0])

        if cmd_type == 0xD0:
            num_vertices = data[pos]
            pos += 1

            if num_vertices > 0:
                vertex_data = data[pos:pos + num_vertices * 2]

                if self.multidraw_3d:
                    sub_cmd = draw_cmd & 0x0F
                    target_planes = []
                    if sub_cmd == 3:  # shadows
                        target_planes = [0]
                    elif sub_cmd == 5:  # midtones
                        target_planes = [0, 1]
                    elif sub_cmd == 7:  # highlights
                        target_planes = [0, 1, 2]
                    else:
                        target_planes = [0]

                    for pi in target_planes:
                        if pi < len(bitplanes) and bitplanes[pi] is not None:
                            if self.outline:
                                draw_scaled_polygon_outline(
                                    num_vertices, vertex_data, scalex, scaley,
                                    ox, oy, bitplanes[pi], self.outline_width
                                )
                            else:
                                draw_filled_scaled_polygon(
                                    num_vertices, vertex_data, scalex, scaley,
                                    ox, oy, bitplanes[pi],
                                    self.xor_mode, self.distort,
                                    self.flip_horizontal, self.flip_vertical
                                )
                else:
                    if self.outline:
                        draw_scaled_polygon_outline(
                            num_vertices, vertex_data, scalex, scaley,
                            ox, oy, target_plane, self.outline_width
                        )
                    else:
                        draw_filled_scaled_polygon(
                            num_vertices, vertex_data, scalex, scaley,
                            ox, oy, target_plane,
                            self.xor_mode, self.distort,
                            self.flip_horizontal, self.flip_vertical
                        )

            pos += num_vertices * 2

        elif cmd_type in (0xE0, 0xF0):
            # Tween command
            tween_from_offset = (data[pos] << 8) | data[pos + 1]
            pos += 2
            tween_to_offset = (data[pos] << 8) | data[pos + 1]
            pos += 2
            tween_t = data[pos]
            pos += 1
            tween_count = data[pos]
            pos += 1

            # Calculate absolute positions
            tween_from_pos = (pos - 6) - tween_from_offset
            tween_to_pos = (pos - 6) + tween_to_offset  # relative to start of this cmd

            # Handle cross-animation references
            from_data = data
            if tween_from_pos < anim.data_start:
                if self.prev_anim is not None:
                    offset_into_prev = anim.data_start - tween_from_pos
                    tween_from_pos = len(self.prev_anim.raw_data) - offset_into_prev
                    from_data = self.prev_anim.raw_data

            shape = self._lerp_tween(from_data, data, tween_from_pos, tween_to_pos,
                                     tween_t, tween_count)

            if shape is not None:
                num_v = shape[0]
                vertex_data = shape[1:1 + num_v * 2]

                if self.outline:
                    draw_scaled_polygon_outline(
                        num_v, vertex_data, scalex, scaley,
                        ox, oy, target_plane, self.outline_width
                    )
                else:
                    draw_filled_scaled_polygon(
                        num_v, vertex_data, scalex, scaley,
                        ox, oy, target_plane,
                        self.xor_mode, self.distort,
                        self.flip_horizontal, self.flip_vertical
                    )

        return pos

    def _lerp_tween(self, from_data: bytes, to_data: bytes,
                    from_pos: int, to_pos: int,
                    tween_t: int, tween_count: int) -> bytes:
        """Linearly interpolate between two shape keyframes."""
        if tween_count == 0:
            return None

        # Skip draw command byte at each position
        from_pos += 1
        to_pos += 1

        try:
            from_length = from_data[from_pos]
            to_length = to_data[to_pos]
        except (IndexError, TypeError):
            return None

        from_pos += 1
        to_pos += 1

        points = max(from_length, to_length)
        buf = self._tween_buffer

        buf[0] = points

        point_mul_from = from_length / points if points > 0 else 1.0
        point_mul_to = to_length / points if points > 0 else 1.0

        amt = tween_t / tween_count if tween_count > 0 else 0.0

        for i in range(points):
            pf = int(i * point_mul_from)
            pt = int(i * point_mul_to)

            try:
                from_y = from_data[from_pos + pf * 2]
                from_x = from_data[from_pos + pf * 2 + 1]
                to_y = to_data[to_pos + pt * 2]
                to_x = to_data[to_pos + pt * 2 + 1]
            except (IndexError, TypeError):
                break

            buf[1 + i * 2] = int(from_y + amt * (to_y - from_y)) & 0xFF
            buf[1 + i * 2 + 1] = int(from_x + amt * (to_x - from_x)) & 0xFF

        return bytes(buf[:1 + points * 2])
