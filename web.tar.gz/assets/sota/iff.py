"""IFF ILBM image loader for State of the Art.

Loads Amiga IFF Interleaved Bitmap (ILBM) format images used for
title screens, credits, and static background textures.
"""

import struct
from sota.graphics import Bitplane


def load_iff_from_data(data: bytes) -> dict:
    """Parse an IFF ILBM file and return image data.

    Returns dict with:
        'width', 'height': image dimensions
        'num_planes': number of bitplanes
        'palette': list of ARGB uint32 color values
        'planes': list of Bitplane objects
    """
    if len(data) < 12:
        return None

    # IFF container: "FORM" + size + type
    form_id = data[0:4]
    if form_id != b'FORM':
        return None

    form_type = data[8:12]
    if form_type != b'ILBM':
        return None

    pos = 12
    width = height = num_planes = 0
    palette = []
    body_data = None
    compression = 0

    while pos < len(data) - 8:
        chunk_id = data[pos:pos + 4]
        chunk_size = struct.unpack('>I', data[pos + 4:pos + 8])[0]
        chunk_data = data[pos + 8:pos + 8 + chunk_size]
        pos += 8 + chunk_size
        if chunk_size & 1:
            pos += 1  # pad to even

        if chunk_id == b'BMHD':
            width = struct.unpack('>H', chunk_data[0:2])[0]
            height = struct.unpack('>H', chunk_data[2:4])[0]
            num_planes = chunk_data[8]
            compression = chunk_data[10]

        elif chunk_id == b'CMAP':
            # Color map: 3 bytes per entry (R, G, B)
            num_colors = len(chunk_data) // 3
            for i in range(num_colors):
                r = chunk_data[i * 3]
                g = chunk_data[i * 3 + 1]
                b = chunk_data[i * 3 + 2]
                palette.append(0xFF000000 | (r << 16) | (g << 8) | b)

        elif chunk_id == b'BODY':
            body_data = chunk_data

    if body_data is None or width == 0 or height == 0:
        return None

    # Decode body
    if compression == 1:
        # ByteRun1 decompression
        body_data = _decompress_byterun1(body_data)

    # Deinterleave into bitplanes
    stride = (width + 15) // 16 * 2  # word-aligned
    planes = []
    for p in range(num_planes):
        bp = Bitplane(p, width, height)
        bp.stride = stride
        bp.data = bytearray(stride * height)
        planes.append(bp)

    # ILBM body is stored as interleaved scanlines
    src_pos = 0
    for y in range(height):
        for p in range(num_planes):
            dst_start = y * stride
            for x_byte in range(stride):
                if src_pos < len(body_data):
                    planes[p].data[dst_start + x_byte] = body_data[src_pos]
                src_pos += 1

    return {
        'width': width,
        'height': height,
        'num_planes': num_planes,
        'palette': palette,
        'planes': planes,
    }


def _decompress_byterun1(data: bytes) -> bytes:
    """Decompress Amiga ByteRun1 (PackBits) data."""
    result = bytearray()
    pos = 0
    while pos < len(data):
        n = data[pos]
        pos += 1
        if n < 128:
            # Copy next n+1 bytes literally
            count = n + 1
            result.extend(data[pos:pos + count])
            pos += count
        elif n > 128:
            # Repeat next byte (257-n) times
            count = 257 - n
            if pos < len(data):
                result.extend(bytes([data[pos]]) * count)
            pos += 1
        # n == 128: no-op
    return bytes(result)


def display_iff(iff_data: dict, x: int, y: int, w: int, h: int,
                target_bitplanes: list, target_plane: int) -> list:
    """Display an IFF image onto the target bitplanes.

    x, y, w, h are in 0-240 scale relative to target bitplane.
    Returns the palette from the IFF image.
    """
    if iff_data is None:
        return []

    target_bp = target_bitplanes[target_plane]
    if target_bp is None:
        return iff_data.get('palette', [])

    tw = target_bp.width
    th = target_bp.height

    # Convert 0-240 coords to pixel coords
    dx = x * tw // 240
    dy = y * th // 240
    dw = w * tw // 240
    dh = h * th // 240

    src_planes = iff_data['planes']
    src_w = iff_data['width']
    src_h = iff_data['height']

    # Clear target bitplanes in the blit region before writing.
    # The C reference's scale_scanline overwrites entire words (both 0 and 1 bits),
    # so we must clear first to avoid old pixels persisting.
    for plane_idx in range(len(src_planes)):
        bp_target_idx = target_plane + plane_idx
        if bp_target_idx >= len(target_bitplanes) or target_bitplanes[bp_target_idx] is None:
            continue
        dst_bp = target_bitplanes[bp_target_idx]
        for row in range(dh):
            byte_start = (dy + row) * dst_bp.stride + dx // 8
            byte_end = (dy + row) * dst_bp.stride + (dx + dw + 7) // 8
            for b in range(byte_start, min(byte_end, len(dst_bp.data))):
                dst_bp.data[b] = 0

    # Nearest-neighbor scale blit
    for plane_idx, src_bp in enumerate(src_planes):
        bp_target_idx = target_plane + plane_idx
        if bp_target_idx >= len(target_bitplanes) or target_bitplanes[bp_target_idx] is None:
            continue

        dst_bp = target_bitplanes[bp_target_idx]
        for row in range(dh):
            src_y = row * src_h // dh
            for col in range(dw):
                src_x = col * src_w // dw
                pixel = src_bp.getpixel(src_x, src_y)
                if pixel:
                    dst_bp.putpixel(dx + col, dy + row)

    return iff_data.get('palette', [])
